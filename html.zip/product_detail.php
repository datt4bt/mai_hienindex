<?php require 'header.php';
$id=$_GET['id'];
 ?>
<style type="text/css">
	img{
		width: 80%;
		display: block;
		margin-left: auto;
		margin-right: auto;
	}

</style>

	<!-- Main Header -->

	<!-- End of Main Header -->

	<!-- BreadCrumb Section	 -->

	<!-- End of BreadCrumb Section	 -->
	
	<!-- Main Container -->
	<div class="blog-main-container container">

		<!-- Page Content -->
		<div class="page-content col-md-9">
			
			<!-- Post Container -->
			<div class="container">
				<?php require 'connect.php'; 
					$sql="select * from product where id_product='$id' ";
					$each=mysqli_query($connect,$sql);
					foreach ($each as $sp ) {?>
						<div><h1 style="text-align: center;"><?php echo $sp['name_product']; ?></h1></div>
						<br>
						<div>
							<?php echo $sp['description']; ?>
						</div>
						<?php
					}
				
										?>


			</div>
			<!-- End of Post Container -->

		</div>
		
		<!-- Sidebar Section -->
		
		<!-- Sidebar Section -->
	</div>

	<!-- Top Footer Section -->
	
	<!-- End of Top Footer Section -->

	<!-- Footer Section -->

	<!-- End of Footer Section -->

	<!-- JS Section (Add all the js codes in this section) -->

	<!-- End of JS Section -->
</body>


</html>