<!DOCTYPE html>
<html>
<style type="text/css">

</style>


<head>
	<meta charset="UTF-8">
	<title>Mái hiên Bảo Nam</title><!-- Website's title ( it will be shown in browser's tab ), Change the website's title based on your Hotel information -->
	<meta name="description" content="Puna is a single property real estate template."><!-- Add your Hotel short description -->
	<meta name="keywords" content="Responsive,HTML5,CSS3,XML,JavaScript"><!-- Add some Keywords based on your Hotel and your business and separate them by comma -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=no">
	
<!-- Attach Google fonts -->
	<link rel="stylesheet" type="text/css" href="assets/css/styles.css"><!-- Attach the main stylesheet file -->
</head>
<body>

	<!-- Main Header -->
	<header id="main-header">
		<div class="inner-container container">
			<div class="logo-container col-xs-4 col-md-2">
				<a href="index.php" id="top-logo">
					<span class="sub-title">mái hiên</span>
					<span class="title"><b>B</b>ao<b>N</b>am</span>
				</a>
			</div>
			<div class="nav-container col-xs-8 col-md-10">
				<div class="t-header clearfix">
					
					<div class="contact-info hidden-xs hidden-sm">
						<ul class="list-inline">
							<li  class="phone"><b>Hotline:</b></li>
							<li  class="phone"><a href="tel:+84917684909"><b>0917684909</b></a></li>
							<li  class="phone"><b>-</b></li>
							<li  class="phone"><a href="tel:+84919850696"><b>0919850696(Mr Dũng)</b></a></li>
						</ul>
					</div>
				</div>
				<div class="b-header hidden-xs hidden-sm ">
					<nav id="main-menu">
						<ul class="list-inline">
							<li class="active home"><a href="index.php">Trang Chủ</a></li>
							
			<li><a href="product_detail.php?id=1">Mái xếp</a></li>							
			<li><a href="product_detail.php?id=2">Mái hiên</a></li>
			<li><a href="product_detail.php?id=3">Bạt che tự cuốn</a></li>
			<li><a href="product_detail.php?id=4">Mái nhựa Poly</a></li>
			<li><a href="product_detail.php?id=5">Mái tôn</a></li>
			<li><a href="product_detail.php?id=6">Dù che ngoài trời</a></li>
							
							
							
						</ul>
					</nav>
				</div>
				<!-- Menu Handel -->
				<div id="main-menu-handle" class="hidden-md hidden-lg"><i class="fa fa-bars"></i></div>
			</div>
		</div>
		<div id="mobile-menu-container" class="hidden-md hidden-lg"></div>
	</header>
	<!-- End of Main Header -->
	
	<!-- Main Slider -->
	<div id="main-slider">
		<div class="items">
            <div class="img-container" style="background-image:url(assets/img/slider/banner1.jpg)"></div><!-- Change the URL section based on your image\'s name -->
            <div class="slide-caption">
            	<a href="#">
	            	<span class="title">Mái hiên Bảo Nam</span>
	            	<span class="">Chuyên thi công tại các khu vực Tp HCM,Đồng Nai và các tỉnh lân cận</span>
	            	<span class="corner-box"></span>
            	</a>
            </div>
        </div>
        <div class="items">
            <div class="img-container" style="background-image:url(assets/img/slider/banner2.jpg)"></div>
            <div class="slide-caption">
            	<a href="#">
	            	<span class="">Liện hệ:0917684909-0919850696(Mr Dũng)</span>
	            	<span class=""></span>
	            	<span class="corner-box"></span>
            	</a>
            </div>
        </div>
        <div class="items">
            <div class="img-container" style="background-image:url(assets/img/slider/banner3.png)"></div>
            <div class="slide-caption">
            	<a href="#">
	            	<span class="title"></span>
	            	<span class="subtitle"></span>
	            	<span class="corner-box"></span>
            	</a>
            </div>
        </div>
    </div>
    	<!-- JS Section (Add all the js codes in this section) -->
	<script type="text/javascript" src="assets/js/jquery.js"></script>
	<script type="text/javascript" src="assets/js/helper.js"></script>
	<script type="text/javascript" src="assets/js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="assets/js/isotope.pkgd.min.js"></script>
	<script type="text/javascript" src="assets/js/imagesloaded.pkgd.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.magnific-popup.min.js"></script>
	
	<script type="text/javascript" src="assets/js/template.js"></script>
	<!-- End of JS Section -->
<div>
		<style>
.mobile-hotline{display:none}
 
.hotline {position: fixed;
    left: 10px;
    bottom: 10px;
    z-index: 9000;
    display: block;
    background: #fac100;
    color: red;
    padding-top: 5px;padding-bottom:5px; padding-left:12px; padding-right: 12px;
    border-radius: 99px;}
.hotline .hotline-number{font-size:20px; color: #b20000; font-weight: bold}
 
@media  (max-width: 767px) {
 
    .hotline{
 
        display :none;
 
    }
.mobile-hotline{display: block; bottom: 0; width: 100%; background:rgba(0,0,0,0.5); height: 60px; position: fixed; z-index:9999999}
.mobile-hotline .mobile-hotline-left{width: 45%; float: left; text-align: center; background: #00a502; margin-left: 10px; margin-right:5px; margin-top: 7px; height: 45px; border-radius: 4px}
.mobile-hotline .mobile-hotline-left a{color: white; line-height: 46px; font-size:16px; font-weight: bold}
 
.mobile-hotline .mobile-hotline-right{width: 45%; float: right; text-align: center; background: #fac100; margin-left: 5px; margin-right: 10px; margin-top: 7px; height: 45px; border-radius: 4px}
.mobile-hotline .mobile-hotline-right a{color: red; line-height: 46px; font-size: 16px; font-weight: bold}
}
</style>
<a href="tel:+84972939830"><div class="hotline">
<span class="before-hotline">Hotline:</span>
<span class="hotline-number">0972.939.830</span>
</div></a>
<div class="mobile-hotline">
<div class="mobile-hotline-left">
<a href="tel:+84917684909" >Hotline:0917684909</a>

</div>
<div class="mobile-hotline-right">
<a href="https://www.messenger.com/t/100005322932486/" target="blank">Nhắn tin</a>

</div>
</div>