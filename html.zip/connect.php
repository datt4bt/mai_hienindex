<?php 
$connect=mysqli_connect('localhost','root','','mai_hien');
mysqli_set_charset($connect,'utf8');