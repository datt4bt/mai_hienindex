<script src="ckeditor/ckeditor.js"></script>
<?php require 'view/header.php';?>
<!-- end menu -->
<!-- slide -->

<!-- list product -->



<div class="container">


 
  <div class="form-group">
  <h2>Upload hình ảnh</h2>
    <form action="view/product/process_insert_slide_picture.php" method="post" enctype="multipart/form-data" id="formUpload" >
      
      <input type="file" name="img_file[]" multiple="true" onchange="previewImg(event);" id="img_file" accept="image/*">
  
     
      
    

<br>
    <button type="submit" class="btn btn-primary mb-2">Thêm ảnh</button>
</form>

	</div>
<!-- end list product -->



<script src="../jquery-3.3.1.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
</body>

</html>