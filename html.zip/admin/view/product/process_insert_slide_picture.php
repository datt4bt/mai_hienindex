<?php 
$connect=mysqli_connect('localhost','root','','mai_hien');
foreach($_FILES['img_file']['name'] as $name => $value)
{
	$name_img = stripslashes($_FILES['img_file']['name'][$name]);
	$source_img = $_FILES['img_file']['tmp_name'][$name];
	$path_img = "../../../anh_slide/" . $name_img;
	move_uploaded_file($source_img, $path_img);
	$insert="insert into slide_picture(picture) values('$name_img')";
	mysqli_query($connect,$insert);
	
}
 ?>