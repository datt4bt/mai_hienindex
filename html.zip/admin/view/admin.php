<?php

if($error=='loi')
{
	
	?>
	<script>
		alert('Mời bạn đăng nhập.');
	</script>
	<?php
}
?>
<?php
session_start();
if(isset ($_SESSION['id_admin']))
{
	header("location:router.php?controller=ok");
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">

	
	<script language="javascript">
function check_login()
{
	var loi3=document.getElementById("loi3");
	var loi4=document.getElementById("loi4");
	//kiểm tra ten_admin
	if(document.form_login.user_admin.value=="" || document.form_login.user_admin.value.length<6)
	{
		loi3.innerHTML="Tên không để trống và ít nhất 6 kí tự";
		document.form_login.user_admin.focus();
		return false;
			}
			else
			{
			loi3.innerHTML="";
			
	//kiểm tra password
	if(document.form_login.password_admin.value=="" || document.form_login.password_admin.value.length<6)
	{
		loi4.innerHTML="Mật khẩu không để trống và ít nhất 6 kí tự";
		document.form_login.password_admin.focus();
		return false;
			}
			else
			{
				loi4.innerHTML="";
			}
			
}
return true;
}

</script>


</head>
<body>
	



<div class="container" id="container">
        <div class="form-container sign-in-container">
            <form name="form_login" action="" method="POST" onsubmit="return check_login()">
                <h1>Đăng Nhập</h1>
				<input style="width: 100%" type="text" name="user_admin" placeholder="Tên tài khoản" />
				<div id="loi3" style="color: red;" ></div> 
				<input style="width: 100%" type="password"   name="password_admin" placeholder="Password" />
				<div id="loi4" style="color: red ;" ></div>
				<hr>
				<br>
				<br>
               
                <button type="submit" >Đăng nhập</button>
            </form>
        </div>
       
    </div>
    </body>
</html>

<?php

if(isset($_GET['error']))
{
	$error=$_GET['error'];
	?>
	<script>
		alert('Mời bạn đăng nhập.');
	</script>
	<?php
}
?>
<?php
if(empty($_POST['user_admin']) and empty($_POST['password_admin']))
{}
else{

if($_POST['user_admin']=='' || $_POST['password_admin']=='')
{
    echo "Vui lòng điền đủ thông tin";
}
else{
    $user_admin=$_POST['user_admin'];
$password_admin=$_POST['password_admin'];
require('../connect.php');
$select="select * from admin where name_admin='$user_admin' and password_admin='$password_admin'";
$result=mysqli_query($connect,$select);
$count=mysqli_num_rows($result);
if($count==1)
{
    foreach($result as $each)
    session_start();

    $_SESSION['id_admin']=$each['id_admin'];
    $_SESSION['ten_admin']=$each['ten_admin'];
  header("location:router.php?controller=ok");
}
else{
   ?>
   <script type="text/javascript">
   	alert("Loi dang nhap");
   </script>
   <?php
}}}
?>