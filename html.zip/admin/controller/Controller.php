<?php 
class Controller{
	static function home(){
	require 'model/product.php';
	
	require 'view/home.php';

}
static function login(){
	
	if (isset($_GET['error'])) {
		$error=$_GET['error'];
	}
	$error='';
	require 'view/admin.php';

}
}