<?php 
require 'router.php';